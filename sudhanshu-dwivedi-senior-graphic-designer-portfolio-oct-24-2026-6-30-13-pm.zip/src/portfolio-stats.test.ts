import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateStats,
  filterProjectsByCategory,
  getFallbackUrl,
  validateContactForm,
  buildMailtoUrl,
  Project
} from './portfolio-stats';

const mockProjects: Project[] = [
  {
    id: 'p1',
    title: 'Brand Work',
    category: 'Branding & Packaging',
    tags: ['Logo'],
    ratio: '4/3',
    summary: 'Mock brand',
    images: [
      { src: 'https://example.com/1.jpg', sourceUrl: 'https://im.ge/i/1', alt: '1' },
      { src: 'https://example.com/2.jpg', sourceUrl: 'https://im.ge/i/2', alt: '2' }
    ]
  },
  {
    id: 'p2',
    title: 'Sports Poster',
    category: 'Sports Posters',
    tags: ['F1'],
    ratio: '4/5',
    summary: 'Mock sports',
    images: [
      { src: 'https://example.com/3.jpg', sourceUrl: 'https://im.ge/i/3', alt: '3' }
    ]
  }
];

const mockCategories = [
  'All',
  'Branding & Packaging',
  'Sports Posters',
  'Entertainment Posters',
  'YouTube Thumbnails',
  'Social Media'
];

test('calculateStats computes accurate totals without hardcoding', () => {
  const stats = calculateStats(mockProjects, mockCategories, 5, 36);
  assert.equal(stats.totalProjects, 2);
  assert.equal(stats.totalImages, 3);
  assert.equal(stats.totalCategories, 5); // excludes "All"
  assert.equal(stats.yearsOfExperience, 5);
  assert.equal(stats.happyClients, 36);
});

test('filterProjectsByCategory filters accurately', () => {
  const all = filterProjectsByCategory(mockProjects, 'All');
  assert.equal(all.length, 2);

  const sports = filterProjectsByCategory(mockProjects, 'Sports Posters');
  assert.equal(sports.length, 1);
  assert.equal(sports[0].id, 'p2');

  const empty = filterProjectsByCategory(mockProjects, 'Social Media');
  assert.equal(empty.length, 0);
});

test('getFallbackUrl returns deterministic seed url without illegal characters', () => {
  const url = getFallbackUrl('The Batman: Noir & Shadows!', 0);
  assert.match(url, /^https:\/\/picsum\.photos\/seed\/the-batman--noir---shadows--0\/800\/1000/);
});

test('validateContactForm checks required fields and email pattern', () => {
  const invalid = validateContactForm({ name: '', email: 'not-an-email', message: '' });
  assert.equal(invalid.isValid, false);
  assert.ok(invalid.errors.name);
  assert.ok(invalid.errors.email);
  assert.ok(invalid.errors.message);

  const valid = validateContactForm({
    name: 'Alice Cooper',
    email: 'alice@example.com',
    message: 'We need high-impact brand packaging.'
  });
  assert.equal(valid.isValid, true);
  assert.equal(Object.keys(valid.errors).length, 0);
});

test('buildMailtoUrl constructs correctly encoded mailto URI', () => {
  const url = buildMailtoUrl('designer@example.com', 'Alex Smith', 'alex@test.com', 'Excited to work together!');
  assert.ok(url.startsWith('mailto:designer@example.com?subject='));
  assert.ok(url.includes('Project%20Inquiry%20from%20Alex%20Smith'));
  assert.ok(url.includes('alex%40test.com'));
});
