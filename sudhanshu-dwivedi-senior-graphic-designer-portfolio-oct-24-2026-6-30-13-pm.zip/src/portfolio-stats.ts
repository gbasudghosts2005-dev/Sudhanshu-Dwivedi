export interface ProjectImage {
  src: string;
  sourceUrl: string;
  alt: string;
  width?: number;
  height?: number;
}

export interface Project {
  id: string;
  title: string;
  category: string;
  badge?: string;
  tags: string[];
  ratio: string;
  summary: string;
  images: ProjectImage[];
}

export interface ToolItem {
  name: string;
  type?: string;
  desc?: string;
  isAi?: boolean;
}

export interface SiteConfig {
  name: string;
  role: string;
  tagline: string;
  heroPhoto: string;
  aboutPhoto: string;
  bio: string;
  email: string;
  links: {
    behance: string;
    linkedin: string;
  };
  resume: string;
  tools: (string | ToolItem)[];
  editableStat: {
    label: string;
    value: number;
    suffix: string;
  };
  happyClientsStat?: {
    label: string;
    value: number;
    suffix: string;
  };
}

export function calculateStats(
  projects: Project[],
  categories: string[],
  editableYears: number,
  happyClients: number = 36
) {
  const totalProjects = projects.length;
  const totalImages = projects.reduce((acc, p) => acc + (p.images ? p.images.length : 0), 0);
  const totalCategories = categories.filter(c => c.toLowerCase() !== 'all').length;

  return {
    totalProjects,
    totalImages,
    totalCategories,
    yearsOfExperience: editableYears,
    happyClients
  };
}

export function filterProjectsByCategory(projects: Project[], category: string): Project[] {
  if (!category || category === 'All') {
    return projects;
  }
  return projects.filter(p => p.category === category);
}

export function getFallbackUrl(title: string, index: number): string {
  const seed = `${title}-${index}`
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, '-')
    .slice(0, 60);

  return `https://picsum.photos/seed/${seed}/800/1000`;
}

export function validateContactForm(data: { name: string; email: string; message: string }) {
  const errors: Record<string, string> = {};
  if (!data.name || data.name.trim().length === 0) {
    errors.name = 'Please provide your name.';
  }
  if (!data.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    errors.email = 'Please provide a valid email address.';
  }
  if (!data.message || data.message.trim().length === 0) {
    errors.message = 'Please include a message regarding your project.';
  }
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

export function buildMailtoUrl(targetEmail: string, name: string, userEmail: string, message: string): string {
  const subject = encodeURIComponent(`Project Inquiry from ${name}`);
  const body = encodeURIComponent(
    `Hello Sudhanshu,\n\nName: ${name}\nEmail: ${userEmail}\n\nProject Brief:\n${message}\n\nSent via Portfolio Contact Form`
  );
  return `mailto:${targetEmail}?subject=${subject}&body=${body}`;
}
